const express = require('express'); //importing express dependency in application
const app = express(); //initialize express application

app.use(express.static('public'));
 //static folder public getting served (telling express to take content inside public folder)
app.listen(3000, ()=> {
console.log("Application is started");
}) 